# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Todos::Application.config.secret_key_base = '7a316a6e8b711351b0da839a899d595da44288be327642daaeed84c6a8838542e6d4b802b4bd264958cd608a39c3efdd51e9dca8df104ff194b595119b1dee89'
