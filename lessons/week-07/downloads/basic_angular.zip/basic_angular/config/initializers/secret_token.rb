# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
BasicAngular::Application.config.secret_key_base = '3f5a1c05ef38782b843f23507e66d69756fb223770b9954b479cc17505af8e370f0a81014962ce35a5e75028e18ce13d51788c5bf5fd8682b388d5f11e3d1deb'
