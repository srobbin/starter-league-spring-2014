# Be sure to restart your server when you modify this file.

BasicAngular::Application.config.session_store :cookie_store, key: '_BasicAngular_session'
